## Change Log
All notable changes to this project will be documented in this file.

## v1.4.0
### Add
- Add support for sorting of entries

## v1.3.0
### Add
- Add support for multiple feed URLs
